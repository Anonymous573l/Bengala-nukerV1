from websocket import WebSocket
from base64 import b64encode
import random
from colorama import Fore
from pystyle import Colors, Colorate, Center
import string
import json
import websocket
import time
import requests

class Discord:
    def __init__(self, token):
        self.headers={
            'authorization': 'Bot {}'.format(
                token
            )
        }
        self.client=requests.Session()
        self.client.headers = self.headers
    def get_channels(self, guild_id):
        try:
            response = self.client.get(f"https://discord.com/api/v9/guilds/{guild_id}/channels")
            response.raise_for_status()
            channels = [channel['id'] for channel in response.json()]
            return channels
        except Exception as e:
            print(f"{Fore.RED}[-] {Fore.RESET}Failed to get channels for guild '{guild_id}': {e}")
            return []

    def get_roles(self, guild_id):
        try:
            response = self.client.get(f"https://discord.com/api/v9/guilds/{guild_id}/roles")
            response.raise_for_status()
            roles = [role['id'] for role in response.json()]
            return roles
        except Exception as e:
            print(f"{Fore.RED}[-] {Fore.RESET}Failed to get roles for guild '{guild_id}': {e}")
            return []

    def create_channel(self, name, guild_id):
        try:
            response = self.client.post(f"https://discord.com/api/v9/guilds/{guild_id}/channels", json={
                "name": name,
                "permission_overwrites": [],
                "type": 0
            })
            response.raise_for_status()
            print(f"{Fore.GREEN}[+] {Fore.RESET}Channel '{name}' created in guild '{guild_id}'")
        except Exception as e:
            print(f"{Fore.RED}[-] {Fore.RESET}Failed to create channel '{name}' in guild '{guild_id}': {e}")

    def delete_channel(self, channel_id):
        try:
            response = self.client.delete(f"https://discord.com/api/v9/channels/{channel_id}")
            response.raise_for_status()
            print(f"{Fore.GREEN}[-] {Fore.RESET}Channel '{channel_id}' deleted")
        except Exception as e:
            print(f"{Fore.RED}[-] {Fore.RESET}Failed to delete channel '{channel_id}': {e}")

    def create_role(self, guild_id, name):
        try:
            response = self.client.post(f"https://discord.com/api/v9/guilds/{guild_id}/roles", json={
                "name": name
            })
            response.raise_for_status()
            print(f"{Fore.GREEN}[+] {Fore.RESET}Role '{name}' created in guild '{guild_id}'")
        except Exception as e:
            print(f"{Fore.RED}[-] {Fore.RESET}Failed to create role '{name}' in guild '{guild_id}': {e}")

    def delete_role(self, guild_id, role_id):
        try:
            response = self.client.delete(f"https://discord.com/api/v9/guilds/{guild_id}/roles/{role_id}")
            response.raise_for_status()
            print(f"{Fore.GREEN}[-] {Fore.RESET}Role '{role_id}' deleted in guild '{guild_id}'")
        except Exception as e:
            print(f"{Fore.RED}[-] {Fore.RESET}Failed to delete role '{role_id}' in guild '{guild_id}': {e}")

    def send_message(self, message, channel_id):
        try:
            response = self.client.post(f"https://discord.com/api/v9/channels/{channel_id}/messages", json={
                "content": message
            })
            response.raise_for_status()
            print(f"{Fore.GREEN}[+] {Fore.RESET}Message '{message}' sent to channel '{channel_id}'")
        except Exception as e:
            print(f"{Fore.RED}[-] {Fore.RESET}Failed to send message '{message}' to channel '{channel_id}': {e}")