# Copyright
skid = kid, lol you don't know how to program so skiddi, you can use the tool but with the various credits of the real developers, if you copy the code changing the credits you are a real kid who doesn't know how to program and if you do it you will be doxed by some developer lolll



# Credits
developed by NYMUS
Helped by pabnis

# Thank you for using Bengal nuker!!!
Thanks for being one of us, but you will be left out of the crowd if you skid